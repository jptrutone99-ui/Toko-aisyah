package com.tokoaisyah.app.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.tokoaisyah.app.model.ItemKeranjang;
import com.tokoaisyah.app.model.ItemTransaksi;
import com.tokoaisyah.app.model.Produk;
import com.tokoaisyah.app.model.Transaksi;

import java.util.ArrayList;
import java.util.List;

/**
 * Pusat penyimpanan data aplikasi Toko Aisyah menggunakan SQLite.
 * Semua data (produk, transaksi, item transaksi) tersimpan secara permanen
 * di penyimpanan internal perangkat sehingga tetap ada ketika aplikasi
 * ditutup dan dibuka kembali.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "toko_aisyah.db";
    private static final int DB_VERSION = 1;

    // Tabel produk
    public static final String TABLE_PRODUK = "produk";
    public static final String COL_P_ID = "id";
    public static final String COL_P_NAMA = "nama";
    public static final String COL_P_HARGA = "harga";
    public static final String COL_P_STOK = "stok";
    public static final String COL_P_KATEGORI = "kategori";

    // Tabel transaksi
    public static final String TABLE_TRANSAKSI = "transaksi";
    public static final String COL_T_ID = "id";
    public static final String COL_T_KODE = "kode_transaksi";
    public static final String COL_T_TANGGAL = "tanggal";
    public static final String COL_T_TOTAL_HARGA = "total_harga";
    public static final String COL_T_TOTAL_ITEM = "total_item";
    public static final String COL_T_UANG_BAYAR = "uang_bayar";
    public static final String COL_T_KEMBALIAN = "kembalian";

    // Tabel item_transaksi
    public static final String TABLE_ITEM_TRANSAKSI = "item_transaksi";
    public static final String COL_IT_ID = "id";
    public static final String COL_IT_TRANSAKSI_ID = "transaksi_id";
    public static final String COL_IT_PRODUK_ID = "produk_id";
    public static final String COL_IT_NAMA_PRODUK = "nama_produk";
    public static final String COL_IT_HARGA_SATUAN = "harga_satuan";
    public static final String COL_IT_JUMLAH = "jumlah";
    public static final String COL_IT_SUBTOTAL = "subtotal";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_PRODUK + " (" +
                COL_P_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_P_NAMA + " TEXT NOT NULL, " +
                COL_P_HARGA + " REAL NOT NULL DEFAULT 0, " +
                COL_P_STOK + " INTEGER NOT NULL DEFAULT 0, " +
                COL_P_KATEGORI + " TEXT" +
                ")");

        db.execSQL("CREATE TABLE " + TABLE_TRANSAKSI + " (" +
                COL_T_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_T_KODE + " TEXT NOT NULL, " +
                COL_T_TANGGAL + " INTEGER NOT NULL, " +
                COL_T_TOTAL_HARGA + " REAL NOT NULL DEFAULT 0, " +
                COL_T_TOTAL_ITEM + " INTEGER NOT NULL DEFAULT 0, " +
                COL_T_UANG_BAYAR + " REAL NOT NULL DEFAULT 0, " +
                COL_T_KEMBALIAN + " REAL NOT NULL DEFAULT 0" +
                ")");

        db.execSQL("CREATE TABLE " + TABLE_ITEM_TRANSAKSI + " (" +
                COL_IT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_IT_TRANSAKSI_ID + " INTEGER NOT NULL, " +
                COL_IT_PRODUK_ID + " INTEGER, " +
                COL_IT_NAMA_PRODUK + " TEXT NOT NULL, " +
                COL_IT_HARGA_SATUAN + " REAL NOT NULL DEFAULT 0, " +
                COL_IT_JUMLAH + " INTEGER NOT NULL DEFAULT 0, " +
                COL_IT_SUBTOTAL + " REAL NOT NULL DEFAULT 0, " +
                "FOREIGN KEY(" + COL_IT_TRANSAKSI_ID + ") REFERENCES " + TABLE_TRANSAKSI + "(" + COL_T_ID + ")" +
                ")");

        db.execSQL("CREATE INDEX idx_item_transaksi_id ON " + TABLE_ITEM_TRANSAKSI + "(" + COL_IT_TRANSAKSI_ID + ")");
        db.execSQL("CREATE INDEX idx_produk_nama ON " + TABLE_PRODUK + "(" + COL_P_NAMA + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Untuk versi pertama, belum ada migrasi khusus.
    }

    // ===================== PRODUK =====================

    public long tambahProduk(Produk p) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_P_NAMA, p.getNama());
        cv.put(COL_P_HARGA, p.getHarga());
        cv.put(COL_P_STOK, p.getStok());
        cv.put(COL_P_KATEGORI, p.getKategori());
        return db.insert(TABLE_PRODUK, null, cv);
    }

    public int updateProduk(Produk p) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_P_NAMA, p.getNama());
        cv.put(COL_P_HARGA, p.getHarga());
        cv.put(COL_P_STOK, p.getStok());
        cv.put(COL_P_KATEGORI, p.getKategori());
        return db.update(TABLE_PRODUK, cv, COL_P_ID + "=?", new String[]{String.valueOf(p.getId())});
    }

    public int hapusProduk(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_PRODUK, COL_P_ID + "=?", new String[]{String.valueOf(id)});
    }

    public Produk getProdukById(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_PRODUK, null, COL_P_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
        Produk p = null;
        if (c.moveToFirst()) {
            p = cursorToProduk(c);
        }
        c.close();
        return p;
    }

    public List<Produk> getSemuaProduk() {
        return cariProduk(null);
    }

    public List<Produk> cariProduk(String keyword) {
        List<Produk> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c;
        if (keyword == null || keyword.trim().isEmpty()) {
            c = db.query(TABLE_PRODUK, null, null, null, null, null, COL_P_NAMA + " ASC");
        } else {
            c = db.query(TABLE_PRODUK, null, COL_P_NAMA + " LIKE ?",
                    new String[]{"%" + keyword.trim() + "%"}, null, null, COL_P_NAMA + " ASC");
        }
        while (c.moveToNext()) {
            list.add(cursorToProduk(c));
        }
        c.close();
        return list;
    }

    public int getJumlahProduk() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_PRODUK, null);
        int count = 0;
        if (c.moveToFirst()) count = c.getInt(0);
        c.close();
        return count;
    }

    public List<Produk> getProdukStokMenipis(int batas) {
        List<Produk> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_PRODUK, null, COL_P_STOK + " <= ?",
                new String[]{String.valueOf(batas)}, null, null, COL_P_STOK + " ASC");
        while (c.moveToNext()) {
            list.add(cursorToProduk(c));
        }
        c.close();
        return list;
    }

    private Produk cursorToProduk(Cursor c) {
        Produk p = new Produk();
        p.setId(c.getLong(c.getColumnIndexOrThrow(COL_P_ID)));
        p.setNama(c.getString(c.getColumnIndexOrThrow(COL_P_NAMA)));
        p.setHarga(c.getDouble(c.getColumnIndexOrThrow(COL_P_HARGA)));
        p.setStok(c.getInt(c.getColumnIndexOrThrow(COL_P_STOK)));
        p.setKategori(c.getString(c.getColumnIndexOrThrow(COL_P_KATEGORI)));
        return p;
    }

    // ===================== TRANSAKSI =====================

    /**
     * Menyimpan transaksi penjualan beserta item-itemnya secara atomik.
     * Stok produk juga otomatis dikurangi sesuai jumlah yang terjual.
     *
     * @return id transaksi yang baru disimpan, atau -1 jika gagal.
     */
    public long simpanTransaksi(Transaksi transaksi, List<ItemKeranjang> itemKeranjangList) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        long transaksiId = -1;
        try {
            ContentValues cv = new ContentValues();
            cv.put(COL_T_KODE, transaksi.getKodeTransaksi());
            cv.put(COL_T_TANGGAL, transaksi.getTanggal());
            cv.put(COL_T_TOTAL_HARGA, transaksi.getTotalHarga());
            cv.put(COL_T_TOTAL_ITEM, transaksi.getTotalItem());
            cv.put(COL_T_UANG_BAYAR, transaksi.getUangBayar());
            cv.put(COL_T_KEMBALIAN, transaksi.getKembalian());
            transaksiId = db.insert(TABLE_TRANSAKSI, null, cv);

            if (transaksiId == -1) {
                db.endTransaction();
                return -1;
            }

            for (ItemKeranjang item : itemKeranjangList) {
                ContentValues itemCv = new ContentValues();
                itemCv.put(COL_IT_TRANSAKSI_ID, transaksiId);
                itemCv.put(COL_IT_PRODUK_ID, item.getProduk().getId());
                itemCv.put(COL_IT_NAMA_PRODUK, item.getProduk().getNama());
                itemCv.put(COL_IT_HARGA_SATUAN, item.getProduk().getHarga());
                itemCv.put(COL_IT_JUMLAH, item.getJumlah());
                itemCv.put(COL_IT_SUBTOTAL, item.getSubtotal());
                db.insert(TABLE_ITEM_TRANSAKSI, null, itemCv);

                // Kurangi stok produk
                ContentValues stokCv = new ContentValues();
                int stokBaru = item.getProduk().getStok() - item.getJumlah();
                if (stokBaru < 0) stokBaru = 0;
                stokCv.put(COL_P_STOK, stokBaru);
                db.update(TABLE_PRODUK, stokCv, COL_P_ID + "=?",
                        new String[]{String.valueOf(item.getProduk().getId())});
            }

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return transaksiId;
    }

    public List<Transaksi> getSemuaTransaksi() {
        List<Transaksi> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_TRANSAKSI, null, null, null, null, null, COL_T_TANGGAL + " DESC");
        while (c.moveToNext()) {
            list.add(cursorToTransaksi(c));
        }
        c.close();
        return list;
    }

    public Transaksi getTransaksiById(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_TRANSAKSI, null, COL_T_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
        Transaksi t = null;
        if (c.moveToFirst()) {
            t = cursorToTransaksi(c);
        }
        c.close();
        return t;
    }

    public List<ItemTransaksi> getItemTransaksi(long transaksiId) {
        List<ItemTransaksi> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_ITEM_TRANSAKSI, null, COL_IT_TRANSAKSI_ID + "=?",
                new String[]{String.valueOf(transaksiId)}, null, null, COL_IT_ID + " ASC");
        while (c.moveToNext()) {
            ItemTransaksi it = new ItemTransaksi();
            it.setId(c.getLong(c.getColumnIndexOrThrow(COL_IT_ID)));
            it.setTransaksiId(c.getLong(c.getColumnIndexOrThrow(COL_IT_TRANSAKSI_ID)));
            it.setProdukId(c.getLong(c.getColumnIndexOrThrow(COL_IT_PRODUK_ID)));
            it.setNamaProduk(c.getString(c.getColumnIndexOrThrow(COL_IT_NAMA_PRODUK)));
            it.setHargaSatuan(c.getDouble(c.getColumnIndexOrThrow(COL_IT_HARGA_SATUAN)));
            it.setJumlah(c.getInt(c.getColumnIndexOrThrow(COL_IT_JUMLAH)));
            it.setSubtotal(c.getDouble(c.getColumnIndexOrThrow(COL_IT_SUBTOTAL)));
            list.add(it);
        }
        c.close();
        return list;
    }

    private Transaksi cursorToTransaksi(Cursor c) {
        Transaksi t = new Transaksi();
        t.setId(c.getLong(c.getColumnIndexOrThrow(COL_T_ID)));
        t.setKodeTransaksi(c.getString(c.getColumnIndexOrThrow(COL_T_KODE)));
        t.setTanggal(c.getLong(c.getColumnIndexOrThrow(COL_T_TANGGAL)));
        t.setTotalHarga(c.getDouble(c.getColumnIndexOrThrow(COL_T_TOTAL_HARGA)));
        t.setTotalItem(c.getInt(c.getColumnIndexOrThrow(COL_T_TOTAL_ITEM)));
        t.setUangBayar(c.getDouble(c.getColumnIndexOrThrow(COL_T_UANG_BAYAR)));
        t.setKembalian(c.getDouble(c.getColumnIndexOrThrow(COL_T_KEMBALIAN)));
        return t;
    }

    // ===================== DASHBOARD / STATISTIK =====================

    public double getTotalPenjualanHariIni() {
        return getTotalPenjualanDenganRange(getStartOfDay(0), getStartOfDay(-1) == 0 ? System.currentTimeMillis() : System.currentTimeMillis());
    }

    public long getStartOfDay(int offsetDays) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.add(java.util.Calendar.DAY_OF_MONTH, offsetDays);
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0);
        cal.set(java.util.Calendar.MINUTE, 0);
        cal.set(java.util.Calendar.SECOND, 0);
        cal.set(java.util.Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    public double getTotalPenjualanDenganRange(long start, long end) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT SUM(" + COL_T_TOTAL_HARGA + ") FROM " + TABLE_TRANSAKSI +
                        " WHERE " + COL_T_TANGGAL + " >= ? AND " + COL_T_TANGGAL + " <= ?",
                new String[]{String.valueOf(start), String.valueOf(end)});
        double total = 0;
        if (c.moveToFirst() && !c.isNull(0)) {
            total = c.getDouble(0);
        }
        c.close();
        return total;
    }

    public int getJumlahTransaksiDenganRange(long start, long end) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_TRANSAKSI +
                        " WHERE " + COL_T_TANGGAL + " >= ? AND " + COL_T_TANGGAL + " <= ?",
                new String[]{String.valueOf(start), String.valueOf(end)});
        int total = 0;
        if (c.moveToFirst()) {
            total = c.getInt(0);
        }
        c.close();
        return total;
    }

    public int getItemTerjualDenganRange(long start, long end) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT SUM(it." + COL_IT_JUMLAH + ") FROM " + TABLE_ITEM_TRANSAKSI + " it " +
                        "JOIN " + TABLE_TRANSAKSI + " t ON it." + COL_IT_TRANSAKSI_ID + " = t." + COL_T_ID +
                        " WHERE t." + COL_T_TANGGAL + " >= ? AND t." + COL_T_TANGGAL + " <= ?",
                new String[]{String.valueOf(start), String.valueOf(end)});
        int total = 0;
        if (c.moveToFirst() && !c.isNull(0)) {
            total = c.getInt(0);
        }
        c.close();
        return total;
    }

    public static class ProdukTerlaris {
        public String nama;
        public int totalTerjual;
        public double totalPendapatan;
    }

    public List<ProdukTerlaris> getProdukTerlaris(long start, long end, int limit) {
        List<ProdukTerlaris> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT it." + COL_IT_NAMA_PRODUK + ", SUM(it." + COL_IT_JUMLAH + ") as total_jual, " +
                        "SUM(it." + COL_IT_SUBTOTAL + ") as total_pendapatan " +
                        "FROM " + TABLE_ITEM_TRANSAKSI + " it " +
                        "JOIN " + TABLE_TRANSAKSI + " t ON it." + COL_IT_TRANSAKSI_ID + " = t." + COL_T_ID +
                        " WHERE t." + COL_T_TANGGAL + " >= ? AND t." + COL_T_TANGGAL + " <= ?" +
                        " GROUP BY it." + COL_IT_NAMA_PRODUK +
                        " ORDER BY total_jual DESC LIMIT ?",
                new String[]{String.valueOf(start), String.valueOf(end), String.valueOf(limit)});
        while (c.moveToNext()) {
            ProdukTerlaris pt = new ProdukTerlaris();
            pt.nama = c.getString(0);
            pt.totalTerjual = c.getInt(1);
            pt.totalPendapatan = c.getDouble(2);
            list.add(pt);
        }
        c.close();
        return list;
    }
}
