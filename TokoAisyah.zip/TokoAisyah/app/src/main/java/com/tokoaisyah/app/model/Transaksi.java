package com.tokoaisyah.app.model;

public class Transaksi {
    private long id;
    private String kodeTransaksi;
    private long tanggal; // epoch millis
    private double totalHarga;
    private int totalItem;
    private double uangBayar;
    private double kembalian;

    public Transaksi() {
    }

    public Transaksi(long id, String kodeTransaksi, long tanggal, double totalHarga,
                      int totalItem, double uangBayar, double kembalian) {
        this.id = id;
        this.kodeTransaksi = kodeTransaksi;
        this.tanggal = tanggal;
        this.totalHarga = totalHarga;
        this.totalItem = totalItem;
        this.uangBayar = uangBayar;
        this.kembalian = kembalian;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getKodeTransaksi() {
        return kodeTransaksi;
    }

    public void setKodeTransaksi(String kodeTransaksi) {
        this.kodeTransaksi = kodeTransaksi;
    }

    public long getTanggal() {
        return tanggal;
    }

    public void setTanggal(long tanggal) {
        this.tanggal = tanggal;
    }

    public double getTotalHarga() {
        return totalHarga;
    }

    public void setTotalHarga(double totalHarga) {
        this.totalHarga = totalHarga;
    }

    public int getTotalItem() {
        return totalItem;
    }

    public void setTotalItem(int totalItem) {
        this.totalItem = totalItem;
    }

    public double getUangBayar() {
        return uangBayar;
    }

    public void setUangBayar(double uangBayar) {
        this.uangBayar = uangBayar;
    }

    public double getKembalian() {
        return kembalian;
    }

    public void setKembalian(double kembalian) {
        this.kembalian = kembalian;
    }
}
