package com.tokoaisyah.app.util;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FormatUtil {

    private static final NumberFormat RUPIAH_FORMAT;

    static {
        RUPIAH_FORMAT = NumberFormat.getNumberInstance(new Locale("in", "ID"));
    }

    public static String formatRupiah(double angka) {
        return "Rp " + RUPIAH_FORMAT.format(Math.round(angka));
    }

    public static String formatRupiahTanpaSimbol(double angka) {
        return RUPIAH_FORMAT.format(Math.round(angka));
    }

    public static String formatTanggal(long millis) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy, HH:mm", new Locale("id", "ID"));
        return sdf.format(new Date(millis));
    }

    public static String formatTanggalSingkat(long millis) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", new Locale("id", "ID"));
        return sdf.format(new Date(millis));
    }

    public static String generateKodeTransaksi(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmss", Locale.getDefault());
        return "TRX" + sdf.format(new Date(timestamp));
    }

    /**
     * Parsing input angka dari EditText, membersihkan karakter selain digit.
     */
    public static double parseAngka(String input) {
        if (input == null || input.trim().isEmpty()) return 0;
        String cleaned = input.replaceAll("[^0-9]", "");
        if (cleaned.isEmpty()) return 0;
        try {
            return Double.parseDouble(cleaned);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static int parseInt(String input) {
        if (input == null || input.trim().isEmpty()) return 0;
        String cleaned = input.replaceAll("[^0-9]", "");
        if (cleaned.isEmpty()) return 0;
        try {
            return Integer.parseInt(cleaned);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
