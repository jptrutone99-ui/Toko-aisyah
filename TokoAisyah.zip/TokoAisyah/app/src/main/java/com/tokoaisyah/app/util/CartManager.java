package com.tokoaisyah.app.util;

import com.tokoaisyah.app.model.ItemKeranjang;
import com.tokoaisyah.app.model.Produk;

import java.util.ArrayList;
import java.util.List;

/**
 * Mengelola isi keranjang belanja selama sesi aplikasi berjalan.
 * Singleton sederhana yang dipakai bersama antara MainActivity dan
 * KeranjangActivity.
 */
public class CartManager {

    private static CartManager instance;
    private final List<ItemKeranjang> items = new ArrayList<>();

    private CartManager() {
    }

    public static synchronized CartManager getInstance() {
        if (instance == null) {
            instance = new CartManager();
        }
        return instance;
    }

    public List<ItemKeranjang> getItems() {
        return items;
    }

    /**
     * Menambah produk ke keranjang. Jika produk sudah ada, jumlah ditambah.
     * Jumlah tidak akan melebihi stok yang tersedia.
     *
     * @return true jika berhasil ditambahkan, false jika stok tidak cukup.
     */
    public boolean tambahItem(Produk produk, int jumlahTambahan) {
        for (ItemKeranjang item : items) {
            if (item.getProduk().getId() == produk.getId()) {
                int jumlahBaru = item.getJumlah() + jumlahTambahan;
                if (jumlahBaru > produk.getStok()) {
                    return false;
                }
                item.setJumlah(jumlahBaru);
                return true;
            }
        }
        if (jumlahTambahan > produk.getStok()) {
            return false;
        }
        items.add(new ItemKeranjang(produk, jumlahTambahan));
        return true;
    }

    public boolean updateJumlah(long produkId, int jumlahBaru) {
        for (ItemKeranjang item : items) {
            if (item.getProduk().getId() == produkId) {
                if (jumlahBaru > item.getProduk().getStok()) {
                    return false;
                }
                if (jumlahBaru <= 0) {
                    items.remove(item);
                } else {
                    item.setJumlah(jumlahBaru);
                }
                return true;
            }
        }
        return false;
    }

    public void hapusItem(long produkId) {
        items.removeIf(item -> item.getProduk().getId() == produkId);
    }

    public void kosongkan() {
        items.clear();
    }

    public double getTotalHarga() {
        double total = 0;
        for (ItemKeranjang item : items) {
            total += item.getSubtotal();
        }
        return total;
    }

    public int getTotalJumlahItem() {
        int total = 0;
        for (ItemKeranjang item : items) {
            total += item.getJumlah();
        }
        return total;
    }

    public int getJumlahJenisProduk() {
        return items.size();
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
