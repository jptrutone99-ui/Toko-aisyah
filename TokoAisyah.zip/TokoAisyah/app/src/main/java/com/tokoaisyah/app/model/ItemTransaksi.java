package com.tokoaisyah.app.model;

public class ItemTransaksi {
    private long id;
    private long transaksiId;
    private long produkId;
    private String namaProduk; // disimpan snapshot saat transaksi
    private double hargaSatuan; // snapshot harga saat transaksi
    private int jumlah;
    private double subtotal;

    public ItemTransaksi() {
    }

    public ItemTransaksi(long id, long transaksiId, long produkId, String namaProduk,
                          double hargaSatuan, int jumlah, double subtotal) {
        this.id = id;
        this.transaksiId = transaksiId;
        this.produkId = produkId;
        this.namaProduk = namaProduk;
        this.hargaSatuan = hargaSatuan;
        this.jumlah = jumlah;
        this.subtotal = subtotal;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getTransaksiId() {
        return transaksiId;
    }

    public void setTransaksiId(long transaksiId) {
        this.transaksiId = transaksiId;
    }

    public long getProdukId() {
        return produkId;
    }

    public void setProdukId(long produkId) {
        this.produkId = produkId;
    }

    public String getNamaProduk() {
        return namaProduk;
    }

    public void setNamaProduk(String namaProduk) {
        this.namaProduk = namaProduk;
    }

    public double getHargaSatuan() {
        return hargaSatuan;
    }

    public void setHargaSatuan(double hargaSatuan) {
        this.hargaSatuan = hargaSatuan;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }
}
